package com.cs2i.libraryapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibraryApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
